#include <iostream>
#include <windows.h>

/*Implemente um programa que leia o nome, a idade e o endere¸co de uma pessoa e armazene os
    dados em uma estrutura. Mostre os dados ap´os o cadastro.*/
using namespace std;

struct PESSOA
{
  string nome;
  string endereco;
  int idade;
};

int main()
{
  UINT CPAGE_UTF8 = 65001;
  UINT CPAGE_DEFAULT = GetConsoleOutputCP();
  SetConsoleOutputCP(CPAGE_UTF8);

  PESSOA pessoa;

  cout << "Nome Completo : ";
  cin.ignore(0, ' ');
  getline(cin, pessoa.nome);

  cout << "Endereço : ";
  cin.ignore(0, ' ');
  getline(cin, pessoa.endereco);

  cout << "Idade : ";
  cin >> pessoa.idade;

  system("cls");

  cout << "\t Dados Do Cadastro \t \n\n ";
  cout << "\nNome : " << pessoa.nome;
  cout << "\nEndereço :" << pessoa.endereco;
  cout << "\nIdade : " << pessoa.idade;

  cout << endl
       << endl;
  system("pause");
  return 0;
}